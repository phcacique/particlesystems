import PlaygroundSupport
import Particles

PlaygroundPage.current.needsIndefiniteExecution = true
PlaygroundPage.current.setLiveView(ArtViewController3())
