/*:
 # Partículas
 Você sabe o que é uma [partícula](glossary://particle)?
 */
