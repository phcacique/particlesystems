import SpriteKit
import PlaygroundSupport

open class ArtScene3: SKScene{
    var particles: [Particle] = []
    open var numParticles: Int = 50
    var colors: [UIColor] = [#colorLiteral(red: 0.9998682141, green: 0.8477882147, blue: 0.4652701616, alpha: 1.0),#colorLiteral(red: 0.0, green: 0.7790542245, blue: 0.9885957837, alpha: 1.0),#colorLiteral(red: 0.9299970865, green: 0.4419257045, blue: 0.6210277081, alpha: 1.0)]
    open var isPlaying: Bool = true
    
    open override func sceneDidLoad() {
        self.backgroundColor = #colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)
    }
    
    open func start(){
        
//        let success = "Parabéns! Você acertou!"
//        PlaygroundPage.current.assessmentStatus = .pass(message: success)
        
        particles = []
        for i in 0..<numParticles{
            var p = Particle()
            if self.size.width > 0{
                p.x = CGFloat.random(in: 0..<size.width)
                p.y = CGFloat.random(in: 0..<size.height)
                p.size = CGFloat.random(in: 2...10)
                p.color = colors[ Int.random(in: 0..<colors.count) ]
                
                p.addSpeed(vx: CGFloat.random(in: -3...3), vy: CGFloat.random(in: -3...3))
            }
            particles.append(p)
        }
    }
    
    open override func didChangeSize(_ oldSize: CGSize) {
        start()
    }
    
    open func draw(){
        self.removeAllChildren()
        for i in 0..<numParticles{
            self.addChild(particles[i].getShape())
        }
    }
    
    open override func update(_ currentTime: TimeInterval) {
        if isPlaying {
            for i in 0..<numParticles{
                if particles[i].x > size.width || particles[i].x < 0{
                    particles[i].vx = -particles[i].vx
                }
                if particles[i].y > size.height || particles[i].y < 0{
                    particles[i].vy = -particles[i].vy
                }
                
                particles[i].update()
            }
        }
        draw()
    }
    
}
